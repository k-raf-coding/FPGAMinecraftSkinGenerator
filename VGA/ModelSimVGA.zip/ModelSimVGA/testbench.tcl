`timescale 1ns / 1ns
`default_nettype none

module testbench;

    reg CLOCK_50 = 0;
    reg [3:0] KEY = 0;

    wire [7:0] VGA_R, VGA_G, VGA_B;
    wire VGA_HS, VGA_VS, VGA_BLANK_N, VGA_SYNC_N, VGA_CLK;

    top DUT (
        .CLOCK_50(CLOCK_50),
        .KEY(KEY),
        .VGA_R(VGA_R), .VGA_G(VGA_G), .VGA_B(VGA_B),
        .VGA_HS(VGA_HS), .VGA_VS(VGA_VS),
        .VGA_BLANK_N(VGA_BLANK_N),
        .VGA_SYNC_N(VGA_SYNC_N),
        .VGA_CLK(VGA_CLK)
    );

    always #10 CLOCK_50 = ~CLOCK_50;

    initial begin
        KEY = 4'b0000;             // Assert active-low reset
        repeat (5) @(negedge CLOCK_50);
        KEY = 4'b0001;             // Release reset
        #20000000;                 // Run for 20 ms
        $finish;
    end

endmodule

`default_nettype wire