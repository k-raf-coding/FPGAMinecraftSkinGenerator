`timescale 1ns / 1ns
`default_nettype none

module testbench;

    reg clk = 0;
    reg reset = 1;
    reg write_enable = 0;
    reg [5:0] x = 0;
    reg [5:0] y = 0;
    reg [8:0] color_in = 0;

    wire [8:0] color_out;
    wire ready;

    image_ram DUT (
        .clk(clk),
        .reset(reset),
        .write_enable(write_enable),
        .x(x),
        .y(y),
        .color_in(color_in),
        .color_out(color_out),
        .ready(ready)
    );

    // 50 MHz clock: 20 ns period.
    always #10 clk = ~clk;

    initial begin
        // Hold reset for a few clocks.
        repeat (3) @(negedge clk);
        reset = 0;

        // Wait until the RAM has filled all 4096 pixels with white.
        wait (ready == 1'b1);
        @(negedge clk);

        // Write red (9'b111_000_000) to pixel x=5, y=3.
        x = 6'd5;
        y = 6'd3;
        color_in = 9'b111_000_000;
        write_enable = 1;

        @(negedge clk);
        write_enable = 0;

        // Read the same pixel on the next clock.
        @(posedge clk);
        #1;
        if (color_out !== 9'b111_000_000)
            $display("FAIL: expected red, got %b", color_out);
        else
            $display("PASS: read back red pixel at x=5, y=3");

        $finish;
    end

endmodule

`default_nettype wire