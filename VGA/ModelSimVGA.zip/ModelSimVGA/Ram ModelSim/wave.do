onerror {resume}
quietly WaveActivateNextPane {} 0

add wave -noupdate -divider "Testbench signals"
add wave -noupdate -label clk /testbench/clk
add wave -noupdate -label reset /testbench/reset
add wave -noupdate -label ready /testbench/ready
add wave -noupdate -label write_enable /testbench/write_enable
add wave -noupdate -label x /testbench/x
add wave -noupdate -label y /testbench/y
add wave -noupdate -label color_in /testbench/color_in
add wave -noupdate -label color_out /testbench/color_out

add wave -noupdate -divider "RAM initialization"
add wave -noupdate -label init_address /testbench/DUT/init_address
add wave -noupdate -label address /testbench/DUT/address

TreeUpdate [SetDefaultTree]
configure wave -namecolwidth 140
configure wave -valuecolwidth 80
configure wave -timelineunits ns
update