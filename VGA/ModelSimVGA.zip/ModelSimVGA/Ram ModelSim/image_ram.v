module image_ram (
    input  wire       clk,
    input  wire       reset,
    input  wire       write_enable,
    input  wire [5:0] x, //0 ... 63
    input  wire [5:0] y,
    input  wire [8:0] color_in, //9 bits colors
    output reg  [8:0] color_out,
    output reg        ready //wait signal before showing in the VGA or writing (we write empty if it is off)
);

    reg [8:0] pixels [0:4095]; //64*64 , colors are 9bits
    reg [11:0] init_address;
    wire [11:0] address = {y, x};

    always @(posedge clk) begin
        if (reset) begin
            init_address <= 12'd0;
            ready        <= 1'b0;
            color_out    <= 9'b111_111_111;
        end else if (!ready) begin 
            // Fill one pixel with white on each clock
            pixels[init_address] <= 9'b111_111_111;
            color_out <= 9'b111_111_111;

            if (init_address == 12'd4095) //fully reset , all white
                ready <= 1'b1; // now we can read / write here
            else
                init_address <= init_address + 1'b1;
        end else begin
            if (write_enable)
                pixels[address] <= color_in; //stores the signal

            color_out = pixels[address]; //changed from non blocking,
        end
    end

endmodule